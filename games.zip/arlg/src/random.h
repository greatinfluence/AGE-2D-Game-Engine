#ifndef RANDOM_H_
#define RANDOM_H_

namespace arlg {

void randinit();

int getrand();

int randint(int l, int r);

bool judge(float p);

}

#endif
